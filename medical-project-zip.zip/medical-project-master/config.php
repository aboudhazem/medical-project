<?php 
session_start();

// base file link 
define("BL",__DIR__.'/');
define("BLA",__DIR__.'/admin/');

// base url
define("BU","http://127.0.0.1/tutorials/medical/");
define("BUA","http://127.0.0.1/tutorials/medical/admin/");
define("ASSETS","http://127.0.0.1/tutorials/medical/assets/");

require BL.'functions/db.php'; 




?>

